<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


require __DIR__ . '/frontend.php';
require __DIR__ . '/backend.php';
